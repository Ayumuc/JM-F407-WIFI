/*
 * Copyright © 2008-2014 Stéphane Raimbault <stephane.raimbault@gmail.com>
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#ifndef _MSC_VER
#include <unistd.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include <modbus.h>

/* The goal of this program is to check all major functions of
   libmodbus:
   - write_coil
   - read_bits
   - write_coils
   - write_register
   - read_registers
   - write_registers
   - read_registers

   All these functions are called with random values on a address
   range defined by the following defines.
*/
#define LOOP             60*1000
#define SERVER_ID       17

/* At each loop, the program works in the range ADDRESS_START to
 * ADDRESS_END then ADDRESS_START + 1 to ADDRESS_END and so on.
 */
int main(void)
{
    modbus_t *ctx;
    int rc;
    int nb_loop;
    uint16_t *tab_rp_registers;


    /* TCP */
    ctx = modbus_new_tcp("0.0.0.0", 14189);
    //modbus_set_debug(ctx, TRUE);

    if (modbus_connect(ctx) == -1) {
        fprintf(stderr, "Connection failed: %s\n",
                modbus_strerror(errno));
        modbus_free(ctx);
        return -1;
    }

    tab_rp_registers = (uint16_t *) malloc(20 * sizeof(uint16_t));
    memset(tab_rp_registers, 0, 20 * sizeof(uint16_t));


    nb_loop = 0;
    while (nb_loop++ < LOOP) {
                rc = modbus_read_registers(ctx, 0, 10, tab_rp_registers);
                if (rc < 1) {
                    printf("ERROR modbus_read_registers single (%d)\n", rc);
                }
	       	else 
		{
		    for(int k = 0; k < 10; k++)
		    {
                        printf("%04X ", tab_rp_registers[k]);
		    }

		    printf("%06d\n", nb_loop);
		}
		usleep(19550);
		/*
		sleep(1);
                if(nb_loop == 0x01){
		    tab_rp_registers[0] = 0x01;
		    rc = modbus_write_register(ctx, 101, tab_rp_registers[0]);
		    sleep(5);
		    rc = modbus_write_register(ctx, 102, tab_rp_registers[0]);
		}
		else if(nb_loop == 0x10){
                    tab_rp_registers[0] = 0x02;
                    rc = modbus_write_register(ctx, 101, tab_rp_registers[0]);
                }

    		printf("* modbus_write_register (0):%d\n ", rc);
		*/

    }
    /* Free the memory */
    free(tab_rp_registers);

    /* Close the connection */
    modbus_close(ctx);
    modbus_free(ctx);

    return 0;
}
