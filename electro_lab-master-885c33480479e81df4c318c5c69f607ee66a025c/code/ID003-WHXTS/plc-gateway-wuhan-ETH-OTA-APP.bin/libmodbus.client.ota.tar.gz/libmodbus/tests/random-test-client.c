/*
 * Copyright © 2008-2014 Stéphane Raimbault <stephane.raimbault@gmail.com>
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#ifndef _MSC_VER
#include <unistd.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include <modbus.h>

/* The goal of this program is to check all major functions of
   libmodbus:
   - write_coil
   - read_bits
   - write_coils
   - write_register
   - read_registers
   - write_registers
   - read_registers

   All these functions are called with random values on a address
   range defined by the following defines.
*/
#define LOOP             60*1000
#define SERVER_ID       17

/* At each loop, the program works in the range ADDRESS_START to
 * ADDRESS_END then ADDRESS_START + 1 to ADDRESS_END and so on.
 */
int main(void)
{
    modbus_t *ctx;
    int rc;
    int nb_loop;
    uint16_t *tab_rp_registers;


    /* TCP */
    ctx = modbus_new_tcp("0.0.0.0", 14110);
    //modbus_set_debug(ctx, TRUE);

    if (modbus_connect(ctx) == -1) {
        fprintf(stderr, "Connection failed: %s\n",
                modbus_strerror(errno));
        modbus_free(ctx);
        return -1;
    }

    tab_rp_registers = (uint16_t *) malloc(20 * sizeof(uint16_t));
    memset(tab_rp_registers, 0, 37 * sizeof(uint16_t));


    nb_loop = 0;
    while (nb_loop++ < LOOP) {
                rc = modbus_read_registers(ctx, 36, 1, tab_rp_registers);
                if (rc < 1) {
                    printf("ERROR modbus_read_registers single (%d)\n", rc);
                } else {
                        printf("%04X%04X%04X %d\n", tab_rp_registers[0], tab_rp_registers[1],tab_rp_registers[36], nb_loop);
                        /*printf("%d %d %d %d %d %d - ",
                               tab_rp_registers[6], tab_rp_registers[7],
                               tab_rp_registers[8], tab_rp_registers[9],
                               tab_rp_registers[10], tab_rp_registers[11]);
                        printf("%d %d %d %d %d %d\n",
                               tab_rp_registers[12], tab_rp_registers[13],
                               tab_rp_registers[14], tab_rp_registers[15],
                               tab_rp_registers[16], tab_rp_registers[17]);
			printf("%d %d %d %d %d %d",
                               tab_rp_registers[18], tab_rp_registers[19],
                               tab_rp_registers[20], tab_rp_registers[21],
                               tab_rp_registers[22], tab_rp_registers[23]);
			printf("%d %d %d %d %d %d",
                               tab_rp_registers[24], tab_rp_registers[25],
                               tab_rp_registers[26], tab_rp_registers[27],
                               tab_rp_registers[28], tab_rp_registers[29]);
			printf("%d %d %d %d %d %d\n",
                               tab_rp_registers[30], tab_rp_registers[31],
                               tab_rp_registers[32], tab_rp_registers[33],
                               tab_rp_registers[34], tab_rp_registers[35]);*/
		}
		usleep(9550);
		
		sleep(1);
                if(nb_loop == 0x01){
		    tab_rp_registers[0] = 0x3344;
		    rc = modbus_write_register(ctx, 36, tab_rp_registers[0]);
		    //sleep(5);
		    //rc = modbus_write_register(ctx, 102, tab_rp_registers[0]);
		}
		else if(nb_loop == 0x10){
                    tab_rp_registers[0] = 0x02;
                    rc = modbus_write_register(ctx, 101, tab_rp_registers[0]);
                }

    		printf("* modbus_write_register (0):%d\n ", rc);
		
    }
    
    /* Free the memory */
    free(tab_rp_registers);

    /* Close the connection */
    modbus_close(ctx);
    modbus_free(ctx);

    return 0;
}
