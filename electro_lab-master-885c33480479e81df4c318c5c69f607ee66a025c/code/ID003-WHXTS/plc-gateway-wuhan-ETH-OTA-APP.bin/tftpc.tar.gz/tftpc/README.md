A simple TFTP server and client.

Usage:

- Server: mytftp -l [-p port] [-v]
- Client: mytftp [-p port] [-v] [-r|w file] host

See the `main()` function for argument details.
