#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <modbus.h>
#ifdef _WIN32
# include <winsock2.h>
#else
# include <sys/socket.h>
#endif

/* For MinGW */
#ifndef MSG_NOSIGNAL
# define MSG_NOSIGNAL 0
#endif

#include "unit-test.h"

#include <sys/types.h> 
#include <stdarg.h>
#include <time.h>
#include <pthread.h>
#include "sys/time.h"
#include <sys/ipc.h>
#include <sys/msg.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <assert.h>
#include <getopt.h>             /* getopt_long() */
#include <sys/mman.h>
#include <sys/ioctl.h>

#include <arpa/inet.h> 
#include <netinet/in.h> 

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>

#define REG_NUMS (3+7)
#define MSG_TYPE_NUM 188

typedef struct msg{
	long type;
	int16_t msg_buf[302];
}MSG_BUF;


void printlog(const char *format, ...);

static pthread_mutex_t fileMutex = PTHREAD_MUTEX_INITIALIZER;

int init_tcp()
{
     // 1.创建套接字 - 设置协议
     int sfd = socket(AF_INET,SOCK_STREAM, 0);
     if( 0 > sfd )
     {
         perror("socket");
         exit(-1);
     }
     //2. 解决在close之后会有一个WAIT_TIME，导致bind失败的问题
     int val = 1;
     int ret = setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, (void *)&val, sizeof(int));
     if(ret < 0)
     {
         printlog("setsockopt wait_time");
         exit(1);
     }

     //3. 绑定IP和PORT
     struct sockaddr_in saddr;
     saddr.sin_family = AF_INET;
     saddr.sin_addr.s_addr = INADDR_ANY;
     saddr.sin_port = htons(4188);
     ret = bind(sfd, (struct sockaddr *)&saddr, sizeof(saddr));
     if(ret < 0)
     {
         printlog("bind");
         exit(1);
     }
     //4. 监听
     ret = listen(sfd, 5);
     if(ret == -1)
     {
         printlog("listen");
         exit(1);
     }
     printlog("Server 189 is ready ... ");

     return sfd;
 }

uint msg_cnt = 0;
void* modbus407_main(void* arg)
{
    unsigned char buf[1206];

    int rc;
    key_t key = ftok("/",1);
    int msg_id = msgget(key, IPC_CREAT|0666);
    MSG_BUF msg;
    msg.type = MSG_TYPE_NUM;

    //1. 初始化(创建套接字socket/地址复用+bind/listen)
    int sfd = init_tcp();
    //2. 并发处理客户端（accept / fork） 2-2通信
    while(1)
    {
        int cfd = accept(sfd, NULL, NULL);
        if(cfd == -1)
        {
            perror("accept");
            exit(1);
        }
                
	char client_addr_ip[20];
        struct sockaddr_in newAddr;
        socklen_t client_addr_len = sizeof(newAddr);
        getpeername(cfd, (struct sockaddr*)&newAddr, &client_addr_len);
        // 把ip转换为点分十进制
        inet_ntop(AF_INET, &newAddr.sin_addr, client_addr_ip, sizeof(client_addr_ip));
        printlog("device ip:%s port:%d", client_addr_ip, ntohs(newAddr.sin_port));
         	
        struct tm *ptm = NULL;
        struct timeval tv;
        struct timezone tz;
    	short nMilSec = 0;

    	gettimeofday(&tv, &tz);
	struct timeval timeout;
        timeout.tv_sec = 10;
        int ret = setsockopt(cfd, SOL_SOCKET, SO_RCVTIMEO, (void *)&timeout, sizeof(timeout));
        if(ret < 0)
        {
            printlog("setsockopt recv timeout 3 seconds");
            exit(1);
        }

	while(1)
     	{
            memset(buf, 0, sizeof(buf));
            int len = recv(cfd, buf, sizeof(buf), 0);
            if(len > 0)
            {
	        // raw acc data 
                //for(int k = 0; k < len; k++)
                //{
                //        printf("%02X", buf[k]);
                //}
                //printf(" len = %d ", len);
		gettimeofday(&tv, &tz);
            	ptm = localtime(&tv.tv_sec);
                if(len == 610)
                {
                    if((buf[0] == 0x33) && (buf[1] == 0x55))
                    {
                        memcpy(msg.msg_buf, buf + 6, 604);
                        send(cfd, buf, 6, 0);

                        struct msqid_ds msgstat;

                        rc = msgctl(msg_id, IPC_STAT, &msgstat);
                        msg_cnt = (uint)(msgstat.msg_qnum);
                        //printf("# messagecnt: %u \n", msg_cnt);
                        if(msg_cnt <= 2) 
                        {
                            msgsnd(msg_id, &msg, sizeof(MSG_BUF) - sizeof(long), IPC_NOWAIT);
                        }
			else
			{
		            MSG_BUF msgtmp;
			    msgtmp.type = MSG_TYPE_NUM;
    	                    msgrcv(msg_id, &msgtmp, sizeof(MSG_BUF) - sizeof(long), MSG_TYPE_NUM, IPC_NOWAIT);
                            msgsnd(msg_id, &msg, sizeof(MSG_BUF) - sizeof(long), IPC_NOWAIT);

			}
                    }
                }
            	printlog("[%02d:%02d:%02d.%06d]%d %d\n", ptm->tm_hour, ptm->tm_min, ptm->tm_sec, tv.tv_usec, len, msg_cnt);
            }
            else
            {
    	        msgrcv(msg_id, &msg, sizeof(MSG_BUF) - sizeof(long), MSG_TYPE_NUM, IPC_NOWAIT);
    	        msgrcv(msg_id, &msg, sizeof(MSG_BUF) - sizeof(long), MSG_TYPE_NUM, IPC_NOWAIT);
                printlog("exit recv data");
                break;
            }
        }
         	
    close(cfd);
    }
     
    close(sfd);
    printlog("exit thread modbus407");
}

#include <stdio.h>
#include <signal.h>
#include <sys/time.h>

modbus_mapping_t *mb_mapping;
int16_t accbuf[1200];
int16_t acccnt = 0;
int16_t rxcnt = 0;
void signalHandler(int signo)
{
    switch (signo){
        case SIGALRM:
            //printf("acccnt = %d\n", acccnt);
	    if(acccnt == 300)
            {
	        key_t key = ftok("/",1);
                int msg_id = msgget(key, IPC_CREAT|0666);
                MSG_BUF msgrecv;
                msgrecv.type = MSG_TYPE_NUM;
                
		memset(&msgrecv, 0, sizeof(msgrecv));
		int msgcnt = msgrcv(msg_id, &msgrecv, sizeof(MSG_BUF) - sizeof(long), MSG_TYPE_NUM, IPC_NOWAIT);
                if(msgcnt == 608 )
                {
                    acccnt = 0;
		    rxcnt = 0;
                    memcpy(accbuf, msgrecv.msg_buf, 600);
                    mb_mapping->tab_registers[6] = msgrecv.msg_buf[300];
                    mb_mapping->tab_registers[7] = msgrecv.msg_buf[301];
                }
		else
		{
		    if(rxcnt++ > 1000)
		    {
		        printlog("clear accbuf");
			bzero(accbuf, sizeof(accbuf));
			rxcnt = 0;
                        acccnt = 0;
		    }
		}
            }
	    else
	    {
                modbus_set_float_dcba((accbuf[acccnt + 0] ) * 0.001,        &mb_mapping->tab_registers[0]);
                modbus_set_float_dcba((accbuf[acccnt + 1] ) * 0.001,        &mb_mapping->tab_registers[2]);
                modbus_set_float_dcba((accbuf[acccnt + 2] ) * 0.001,        &mb_mapping->tab_registers[4]);
                acccnt = acccnt + 3;
	    }
            break;
   }
}
int main(int argc, char*argv[])
{
    int s = -1;
    modbus_t *ctx;
    int rc;
    int i;
    int use_backend;
    uint8_t *query;
    int header_length;
    int debug_flag = 0;

    ctx = modbus_new_tcp("0.0.0.0", 14188);
    query = malloc(MODBUS_TCP_MAX_ADU_LENGTH);
    header_length = modbus_get_header_length(ctx);

    if(debug_flag > 0)
        modbus_set_debug(ctx, TRUE);

    mb_mapping = modbus_mapping_new_start_address(
        0, 0,
        0, 0,
        0, REG_NUMS,
        0, 0);
    if (mb_mapping == NULL) {
        fprintf(stderr, "Failed to allocate the mapping: %s\n", modbus_strerror(errno));
        modbus_free(ctx);
        return -1;
    }

    modbus_set_response_timeout(ctx, 2, 0);
    
    pthread_t pthid5;
    if (pthread_create(&pthid5, NULL, modbus407_main, NULL) != 0 )
    {
        printlog("pthread_createi 189 modbus407_main fail");
        return -1;
    }

    signal(SIGALRM, signalHandler);
    struct itimerval new_value, old_value;
    new_value.it_value.tv_sec = 0;
    new_value.it_value.tv_usec = 1;
    new_value.it_interval.tv_sec = 0;
    new_value.it_interval.tv_usec = 10000;
    setitimer(ITIMER_REAL, &new_value, &old_value);


    while(1)
    {
        s = modbus_tcp_listen(ctx, 1);
        modbus_tcp_accept(ctx, &s);
        printlog("==== modbus_tcp189_listen ====");
        for (;;) {
            do {
                rc = modbus_receive(ctx, query);
            } while (rc == 0);

            if (rc == -1 && errno != EMBBADCRC) {
                printlog("modbus_receive Quit the loop: %s", modbus_strerror(errno));
                break;
            }

	    rc = modbus_reply(ctx, query, rc, mb_mapping);
            if (rc == -1) {
                printlog(" modbus_reply Quit the loop: %s", modbus_strerror(errno));
                break;
            }
        }

        printlog("Quit the loop: %s", modbus_strerror(errno));
        if (s != -1) {
            close(s);
        }
    }

    modbus_mapping_free(mb_mapping);
    free(query);
    /* For RTU */
    modbus_close(ctx);
    modbus_free(ctx);

    return 0;
}

/*
* safe_vasprintf();
*/
int safe_vasprintf(char **strp, const char *fmt, va_list ap) 
{
	int retval;

	retval = vasprintf(strp, fmt, ap);
	if (retval == -1) 
	{
		printf("Failed to vasprintf: %s. Bailing out\n", strerror(errno));
		return 1;
	}

	return retval;
}

/*
* plog();
*/
void printlog(const char *format, ...) 
{	
    pthread_mutex_lock(&fileMutex);		
    FILE *fp = NULL;
    va_list vlist;
    char *fmt = NULL;
    time_t rawtime;
    struct tm *info;
    char buffer[40] = {0};
    int len = 0;
								 
    time( &rawtime );
    info = localtime( &rawtime );
    buffer[0] = '.';buffer[1] = '/';
    sprintf(buffer + 2,"%s", asctime(info));
    len = strlen(buffer);
    buffer[2] = '.';buffer[3] = 'd';
    buffer[4] = 'b';buffer[5] = '/';
    buffer[len - 15] = 'w';buffer[len - 14] = 'i';
    buffer[len - 13] = 'n';buffer[len - 12] = 'd';
    buffer[len - 11] = '.';buffer[len - 10] = 'r';
    buffer[len - 9] = '3';buffer[len - 8] = '3';
    buffer[len - 7] = '9';buffer[len - 6] = '9';
    buffer[len - 5] = '.';buffer[len - 4] = 't';
    buffer[len - 3] = 'x';buffer[len - 1] = 0;
    buffer[len - 2] = 't';buffer[len] = 0;

    // Open debug info output file.
    if (!(fp = fopen(buffer, "a+"))) {
        pthread_mutex_unlock(&fileMutex);
        return;
    }
    
    va_start(vlist, format);	
    safe_vasprintf(&fmt, format, vlist);
    va_end(vlist);
			
    if (!fmt) {
        pthread_mutex_unlock(&fileMutex);
        return;
    }
				

    struct tm *ptm = NULL;
    struct timeval tv;
    struct timezone tz;
    short nMilSec = 0;

    gettimeofday(&tv, &tz); 
    nMilSec = (long long)tv.tv_usec/1000;
    ptm = localtime(&tv.tv_sec);

    fprintf(fp, "[%04d.%02d.%02d-%02d:%02d:%02d.%03d] %s\n", 
		ptm->tm_year + 1900, 
		ptm->tm_mon + 1,
		ptm->tm_mday, 
		ptm->tm_hour, 
		ptm->tm_min, 
		ptm->tm_sec, 
		nMilSec, 
		fmt);
    
    free(fmt);
    fsync(fileno(fp));
    fclose(fp);
    pthread_mutex_unlock(&fileMutex);
}
