#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <netinet/in.h> 
    
#define PORT     8001 
#define MAXLINE  494
    
// Driver code 
int main() { 
    int sockfd; 
    char buffer[MAXLINE]; 
	unsigned char sendbuf[8];
    char *hello = "Hello from client"; 
    struct sockaddr_in     servaddr, localaddr; 
    
    // Creating socket file descriptor 
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) { 
        perror("socket creation failed"); 
        exit(EXIT_FAILURE); 
    } 
    
    memset(&servaddr, 0, sizeof(servaddr)); 
        
    // Filling server information 
    servaddr.sin_family = AF_INET; 
    servaddr.sin_port = htons(4567); 
    servaddr.sin_addr.s_addr = inet_addr("192.168.0.19"); //INADDR_ANY; 

    localaddr.sin_family = AF_INET; 
    localaddr.sin_port = htons(8001); 
    localaddr.sin_addr.s_addr = inet_addr("0.0.0.0"); //INADDR_ANY; 

struct timeval tv_out;
tv_out.tv_sec = 0;
tv_out.tv_usec = 500000;
setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO, &tv_out, sizeof(tv_out));

    // Bind the socket with the server address 
    if ( bind(sockfd, (const struct sockaddr *)&localaddr,  
            sizeof(localaddr)) < 0 ) 
    { 
        perror("bind failed"); 
        exit(EXIT_FAILURE); 
    } 
       
       
       
     
   int n, len = 0;    
   while(1){ 
	memset(sendbuf, 0, 8);
	//30 02 06 00 00 00 00 00
	sendbuf[0] = 0x30; sendbuf[1] = 0x02; sendbuf[2] = 0x06; sendbuf[3] = 0x00;
	sendbuf[4] = 0x00; sendbuf[5] = 0x00; sendbuf[6] = 0x00; sendbuf[7] = 0x00;
	if(n <= 0){
		sendto(sockfd, (const unsigned char *)sendbuf, 6, MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
	}
        
            
    	n = recvfrom(sockfd, (char *)buffer, MAXLINE,  0, (struct sockaddr *) &localaddr,   &len); 
	for(int i = 0; i<n; i++)
		printf("%02X", buffer[i]);
    	printf("servaddr : %d-%s :%08x :%04x\n", n, buffer, servaddr.sin_addr.s_addr, servaddr.sin_port); 
}
    close(sockfd); 
    return 0; 
}
