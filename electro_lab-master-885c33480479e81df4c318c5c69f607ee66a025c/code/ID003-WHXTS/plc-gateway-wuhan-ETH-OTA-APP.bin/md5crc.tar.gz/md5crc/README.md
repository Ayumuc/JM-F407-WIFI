# md5
C语言实现的MD5算法源码
```
usage:
    ./md5 -f file ...
    ./md5 string ...
```
